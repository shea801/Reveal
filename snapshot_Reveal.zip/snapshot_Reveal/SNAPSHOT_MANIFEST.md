# Sanitized Reveal Project Snapshot

Snapshot date: 2026-11-16

## Purpose

This is a source-only handoff for reviewing the current Reveal project outside
the development machine. It reflects the committed Reveal source and corrected
v1.0.0 documentation, with a sanitized README. It is not a
database backup or a packaged release.

## Included

- Reveal 1.0.0 source: analytics, data access, data ingestion, runtime
  configuration, dashboard, maintenance, database tooling, and CLI scripts.
- Application contracts and product specifications in `mvp/`, `scripts/`,
  and `docs/`.
- Synthetic-data and mocked unit tests in `Tests/`.
- Project README, packaging metadata, locked dependencies, CI workflow, and
  a snapshot-specific protective `.gitignore`.

The source includes the starter-database exporter and installer, but no
starter archive or SQLite database. It includes environment-based runtime
configuration, not local credential values.

## Sanitization And Exclusions

- The README's repository-owner URL and personal author section were removed.
- The original license file was omitted because its copyright notice contains
  an identifying name. Refer to the source repository for the actual license;
  this snapshot is a review handoff, not a substitute distribution.
- The snapshot's `.gitignore` uses the sanitized protective rules from the
  previous project handoff.
- Git history, IDE files, caches, bytecode, virtual environments, built
  distributions, databases, source datasets, archives, generated results,
  local configuration, and credentials are excluded.
- The current Reveal repository does not contain the older project's
  `look_here_first/` directory or research notebooks. The README distinguishes
  optional data-root directories from those supplied by a fresh clone.
- The ZIP omits macOS metadata files and resource forks.

## Current Project State

- `pyproject.toml` declares version 1.0.0.
- The dashboard and CLI consume application-service results; financial
  calculations remain in analytics.
- The starter-data workflow packages a selected SQLite subset and validates
  checksums, SQLite integrity, and foreign keys before installing either
  database. Existing databases are not overwritten.
- Local data roots and live API credentials are configured through
  environment variables. The snapshot contains neither.

## Verification

- 92 tracked source and documentation files were selected, excluding the
  identifying license file. This manifest is additional.
- Snapshot content was scanned for personal names, home-directory paths,
  email addresses, and common credential formats.
- An isolated test run with no data-root or API-key environment variables
  passed: 208 tests, with one existing pandas deprecation warning.
- Ruff passed across the staged snapshot.
