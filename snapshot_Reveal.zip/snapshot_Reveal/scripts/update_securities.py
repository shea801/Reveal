"""Command-line entrypoint for the recurring Investment securities update."""

from pathlib import Path
import sys


PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from maintenance.security_updater import main


if __name__ == "__main__":
    raise SystemExit(main())
